<template>
  <div style="padding:0 10px;margin-top:10px;">
    <span style="position:absolute;top:50%;left:50%;z-index:99;display:block;width:100px;height:100px;"></span>
    <el-button @click="open1" v-show="false">消息</el-button>
    <!-- <el-button :plain="true" @click="open2">成功</el-button>
    <el-button :plain="true" @click="open3">暂无数据</el-button>
    <el-button :plain="true" @click="open4">错误</el-button> -->
    <section>
      <!--工具条-->
      <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
        <el-form :inline="true" :model="filters.name" class="demo-form-inline" style="position:relative;">
          <el-form-item label="冷库列表">
            <el-select v-model="filters.name" filterable placeholder="请选择" @change="select_node">
              <el-option v-for="item in oprations" :key="item.index" :label="item.name" :value="item.id" ref="dataInfo">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="设备名称" id="shebeis" style="margin-left:1%">
                        <div style="width: 149px;height: 30px;border:1px solid #BFCBD9;border-radius: 5px;overflow:hidden;">
              <el-select v-model="value11" @change="selectAll" multiple collapse-tags placeholder="请选择" style="width: 200px;margin-bottom:-100px;">
                <el-option v-for="item in allnums" :key="item.id" :label="item.nodename" :value="item.id" style="width: 200px">
                </el-option>
              </el-select>

            </div>
                    </el-form-item>
          <el-form-item label="时间区间">
            <div class="block">
              <el-date-picker v-model="value1" type="datetime" value-format="yyyy-MM-dd" placeholder="选择开始日期时间">
              </el-date-picker>
            </div>
          </el-form-item>
          <el-form-item label="-">
            <div class="block">
              <el-date-picker v-model="value2" type="datetime" value-format="yyyy-MM-dd" placeholder="选择结束日期时间">
              </el-date-picker>
            </div>
          </el-form-item>
          <el-form-item label="时间间隔" id="interval_time">
            <el-input v-model="interval" class="interval_inpu" style="width:80px;"></el-input>
            <sapn style="position:absolute;top:0;right:0px">分钟</sapn>
          </el-form-item>
          <el-form-item>
            <!-- 查询 -->
            <el-button type="primary" @click="getUserst">查询</el-button>

            <el-button :plain="false" @click="open8" v-show="false"></el-button>
          </el-form-item>
          <el-form-item style="float:right;cursor: pointer;padding-left:10px;" @click="Pdf"  v-loading="loading3">
            <i>
              <img src="../../assets/icon/pdf.png" width="20" height="14" @click="Pdf">
            </i>
            <a style="color:#328fea;text-decoration:none;" @click="Pdf">Pdf</a>
          </el-form-item>
          <el-form-item style="float:right;cursor: pointer;" @click="excels" v-loading="loading2">
            <i>
              <img src="../../assets/icon/excel.png" width="20" height="14" @click="excels">
            </i>
              <a style="color:#328fea;" @click="excels">Excel</a>
          </el-form-item>
          <!-- <div style="width:100%; height:100%; position:absolute;top:0px;left:0px;background:red;text-align:center;" ><span v-loading="loading2"></span></div> -->
        </el-form>
      </el-col>
      <!-- 列表-新加了一个id用于PDF导出 -->
      <el-table-column prop="nodename" label="设备名称" width="150" fixed="left" :show-overflow-tooltip="true">
      </el-table-column>
      <template>
        <section class="chart-container chart1-container" :style={height:liuHeights}>
          <el-row style="margin: 2% 0 0 0" v-if="xianshi">
            <el-col :span="8" style="position:relative" v-if="allnode[0]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[0].nodename">▌{{allnode[0].nodename}}</div>
              <div class="jump_info" @click="jump_info(1)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart1" style="margin:0 auto;;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[1]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[1].nodename">▌{{allnode[1].nodename}}</div>
              <div class="jump_info" @click="jump_info(2)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart2" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[2]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[2].nodename">▌{{allnode[2].nodename}}</div>
              <div class="jump_info" @click="jump_info(3)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart3" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
          </el-row>

            <el-col :span="8" style="position:relative" v-if="allnode[3]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[3].nodename">▌{{allnode[3].nodename}}</div>
              <div class="jump_info" @click="jump_info(4)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart4" style="margin:0 auto;;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[4]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[4].nodename">▌{{allnode[4].nodename}}</div>
              <div class="jump_info" @click="jump_info(5)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart5" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[5]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[5].nodename">▌{{allnode[5].nodename}}</div>
              <div class="jump_info" @click="jump_info(6)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart6" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>


            <el-col :span="8" style="position:relative" v-if="allnode[6]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[6].nodename">▌{{allnode[6].nodename}}</div>
              <div class="jump_info" @click="jump_info(7)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart7" style="margin:0 auto;;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[7]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[7].nodename">▌{{allnode[7].nodename}}</div>
              <div class="jump_info" @click="jump_info(8)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart8" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[8]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[8].nodename">▌{{allnode[8].nodename}}</div>
              <div class="jump_info" @click="jump_info(9)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart9" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>


            <el-col :span="8" style="position:relative" v-if="allnode[9]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[9].nodename">▌{{allnode[9].nodename}}</div>
              <div class="jump_info" @click="jump_info(10)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart10" style="margin:0 auto;;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[10]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[10].nodename">▌{{allnode[10].nodename}}</div>
              <div class="jump_info" @click="jump_info(11)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart11" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>
            <el-col :span="8" style="position:relative" v-if="allnode[11]" v-loading="loading">
              <div class="titleNname" :title="'▌'+allnode[11].nodename">▌{{allnode[11].nodename}}</div>
              <div class="jump_info" @click="jump_info(12)">
                <img src="../../assets/icon/lishi.png" width="20" alt="列表详情">
              </div>
              <div id="chart12" style="margin:0 auto;width:96%;height:200px;border: 1px solid #C7C7C7;"></div>
            </el-col>

        </section>
      </template>
      <!-- 弹出开始 -->
      <div class="content" v-if="newadds">

        <div class="contenter">
         <div class="delet" @click="delet">ㄨ</div>
          <el-table :data="all_node" highlight-current-row :height="500" style="border-right:solid 1px #dfe6ec;height:300px;overflow: hidden;"
            @selection-change="handleSelectionChange">
            <!-- 多选框去除 -->
            <!-- <el-table-column type="selection" width="55" label="全选/取消">
            </el-table-column> -->
            <el-table-column prop="nodeName" label="节点名称" width="140" :show-overflow-tooltip="true">
            </el-table-column>
            <el-table-column prop="temperature1" label="温度" width="100">
            </el-table-column>
            <el-table-column prop="hum" label="湿度" min-width="100" :show-overflow-tooltip="true">
            </el-table-column>
            <el-table-column prop="gpsTime" label="记录时间" min-width="380" :show-overflow-tooltip="true" sortable>
            </el-table-column>
            <el-table-column prop="installPos" label="安装位置" min-width="380" :show-overflow-tooltip="true">
            </el-table-column>
          </el-table>
          
          <el-footer class="footer-fenye">
            <!--工具条-->
            <el-col :span="24" class="toolbar-bot">
              <span class="demonstration" style="margin-top: 10px; line-height:32px;">共:{{total}}条</span>
              <el-pagination style="cursor:pointer" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage1" :page-size="size"
                layout="prev, pager, next, jumper" :total="total">
              </el-pagination>
            </el-col>
          </el-footer>
        </div>
      </div>
      <!-- 弹出结束 -->
    </section>
  </div>
</template>

<script>
var liuHeight = document.documentElement.clientHeight - 180 + "px";
import util from "../../common/js/util";
import axios from "axios";
import echarts from "echarts";
import {
  getUserListPage,
  removeUser,
  batchRemoveUser,
  editUser,
  addUser,
  history,
  allNode,
  unitTree,
  newhistory,
  exportPdf,
  excels,
  getNode,
  nodeinfo
} from "../../api/api";
export default {
  data() {
    return {
      vehicleIds:"",
      value11: "",
      value12: "",
      allnums: [],
      loading2: false,
      loading3: false,
      interval: 5,
      pdfUrl: "",
      tmp1min: "",
      tmp2min: "",
      tmp3min: "",
      tmp4min: "",
      tmp5min: "",
      tmp6min: "",
      tmp7min: "",
      tmp8min: "",
      tmp9min: "",
      tmp10min: "",
      tmp12min: "",
      tmp1max: "",
      tmp2max: "",
      tmp3max: "",
      tmp4max: "",
      tmp5max: "",
      tmp6max: "",
      tmp7max: "",
      tmp8max: "",
      tmp9max: "",
      tmp10max: "",
      tmp11max: "",
      tmp12max: "",
      hum1min: "",
      hum2min: "",
      hum3min: "",
      hum4min: "",
      hum5min: "",
      hum6min: "",
      hum7min: "",
      hum8min: "",
      hum9min: "",
      hum10min: "",
      hum12min: "",
      hum1max: "",
      hum2max: "",
      hum3max: "",
      hum4max: "",
      hum5max: "",
      hum6max: "",
      hum7max: "",
      hum8max: "",
      hum9max: "",
      hum10max: "",
      hum11max: "",
      hum12max: "",
      allinfo: [],
      liuHeights: "",
      newadds: false,
      xianshi: false,
      all_node: [],
      num: "",
      // echart图
      myChart1: null,
      myChart2: null,
      myChart3: null,
      myChart4: null,
      myChart5: null,
      myChart6: null,
      myChart7: null,
      myChart8: null,
      myChart9: null,
      jiedianid: [],
      a: [],
      allnodedetail: [],
      // myChart: [],
      allnum: [],
      label: "",
      value: "",
      value1: "",
      value2: "",
      value3: "",
      value4: "",
      filters: {
        name: "",
        id: ""
      },
      select: "",
      allnode: [],
      oprations: [],
      users: [],
      currentPage1: 1,
      total: 0,
      page: 1,
      size: 15,
      loading: false,
      sels: [], //列表选中列
      editLoading: false,
      startTime: "",
      endTime: "",
      vehicleId: ""
    };
  },
  beforeCreate() {},
  // created() {

  // },
  // beforeMount() {},
  //  beforeUpdate () {
  //   this.getUserst()
  // },
  //echart图
  mounted: function() {
    this.liuHeights = liuHeight;
    this.loading = true;
    allNode().then(data => {
      this.loading = false;
      if (data.data.code == -1) {
        this.$message({
          message: msg,
          type: "error"
        });
      } else {
        this.$nextTick(() => {
          this.allnode = data.data.msg;
          for (var i = 0; i < this.allnode.length; i++) {
            this.allnode[i].nodename = this.allnode[i].name;
          }
          this.getUserst();
        });
      }
    });
    // 第二个echarts图
    // 第三个echarts图
    // 第四个echarts图
    // 第5个echarts图
    // 第6个echarts图
    // 第7个echarts图
    // 第8个echarts图
    // 第9个echarts图

    /*ECharts图表*/
  },

  created: function() {
    this.loading = true;
    unitTree().then(data => {
      this.loading = false;
      if (data.data.code == -1) {
        this.$message({
          message: msg,
          type: "error"
        });
      } else {
        this.oprations = data.data.msg;
        this.filters.name = data.data.msg[0].id;
        // alert(data.data.msg[0].name)
      }
    });
    this.sysUserName = ruleForm2.account;
  },
  methods: {
    Pdf() {
      var that = this;
      that.size = 99999;
      that.page = 1;
      this.loading3 = true;
      setTimeout(() => {
        this.loading3 = false;
      }, 5000);
      window.location.href =
        "http://114.55.138.209:8091/jygpsTmp/vehicletmpdetailinfo/exportPdf?unitIds=" +
        this.filters.name +
        "&startTime=" +
        that.value1 +
        "&endTime=" +
        that.value2 +
        "&interval=" +
        that.interval +
        "&size=" +
        that.size +
        "&page=" +
        that.page+
        "&vehicle_Ids=" +
        that.vehicleIds;
      that.size = 15;
    },
    excels() {
      var that = this;
      that.size = 99999;
      that.page = 1;
      this.loading2 = true;
      setTimeout(() => {
        this.loading2 = false;
      }, 5000);
      window.location.href =
        "http://114.55.138.209:8091/jygpsTmp/vehicletmpdetailinfo/exportExcel?unitIds=" +
        this.filters.name +
        "&startTime=" +
        that.value1 +
        "&endTime=" +
        that.value2 +
        "&interval=" +
        that.interval +
        "&size=" +
        that.size +
        "&page=" +
        that.page+
        "&vehicle_Ids=" +
        that.vehicleIds;
      that.size = 15;
    },
    open1() {
      this.$message({
        message: "暂无数据",
        type: "warning"
      });
    },
    // 下拉列表
    select_node() {
      // alert(1)
      this.value11 = [];
      // this.filters.name = "";
      this.getUserst();
    },
    selectAll(val){
      console.log(val.join(','))
      this.vehicleIds=val.join(',')
    },
    handleSizeChange(val) {
      // alert(`每页 ${val} 条`);
      this.size = val;
      this.jump_info(this.num);
    },
    handleCurrentChange(val) {
      this.page = val;
      this.jump_info(this.num);
    },
    // 第一个echarts图
    displayEchart1(data) {
      this.myChart1 = echarts.init(document.getElementById("chart1"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp1max = tmp0max;
      //   this.tmp1min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp1max = maxs;
      //   this.tmp1min = mins;
      // }
      // for(var j=0;j<tmp1Array.length;j++){
      //   var numbe=""
      //   if(tmp1Array[j]==""){
      //     numbe=j
      //     tmp1Array.splice(numbe,1)
      //   }

      // }
      // for(var j=0;j<tmp1Array.length;j++){
      //   var numbe=""
      //   if(tmp1Array[j]==""){
      //     alert(tmp1Array[37])

      //   }

      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option1 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp1min,
            max: this.tmp1max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      this.myChart1.setOption(option1);
    },
    drawChart1() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      this.value1 = this.value3;
      this.value2 = this.value4;
      // alert(this.allnode[0].id)

      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[0].id

        // interval:this.interval
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        console.log(res);
        this.loading = false;
        var data = res.msg.data;

        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp1max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp1max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp1min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp1min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart1(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts1() {
      this.displayEchart1();
    },
    // 第二个echarts图
    displayEchart2(data) {
      this.myChart2 = echarts.init(document.getElementById("chart2"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp2max = tmp0max;
      //   this.tmp2min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp2max = maxs;
      //   this.tmp2min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option2 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp2min,
            max: this.tmp2max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      this.myChart2.setOption(option2);
    },
    drawChart2() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[1].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;

        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp2max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp2max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp2min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp2min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart2(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts2() {
      this.displayEchart2();
    },
    // 第三个echarts图
    displayEchart3(data) {
      this.myChart3 = echarts.init(document.getElementById("chart3"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp3max = tmp0max;
      //   this.tmp3min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp3max = maxs;
      //   this.tmp3min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option3 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp3min,
            max: this.tmp3max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };

      this.myChart3.setOption(option3);
      // console.log(this.allnodedd)
    },
    drawChart3() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[2].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp3max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp3max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp3min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp3min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart3(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts3() {
      this.displayEchart3();
    },
    // 第四个echarts图
    displayEchart4(data) {
      this.myChart4 = echarts.init(document.getElementById("chart4"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp4max = tmp0max;
      //   this.tmp4min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp4max = maxs;
      //   this.tmp4min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option4 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp4min,
            max: this.tmp4max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      this.myChart4.setOption(option4);
      // console.log(this.allnodedd)
    },
    drawChart4() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[3].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;

        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp4max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp4max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp4min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp4min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart4(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts4() {
      this.displayEchart4();
    },
    // 第5个echarts图
    displayEchart5(data) {
      this.myChart5 = echarts.init(document.getElementById("chart5"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }

      //   this.tmp5max = tmp0max;
      //   this.tmp5min = tmp0min;
      // }

      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }

        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option5 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            // type: "category",
            // boundaryGap: false,
            // axisLabel: {
            //   fontSize: "9"
            // },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],

        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp5min,
            max: this.tmp5max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      this.myChart5.setOption(option5);
      // console.log(this.allnodedd)
    },
    drawChart5() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[4].id
        // interval:10
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          this.total = res.msg.total;
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp5max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp5max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp5min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp5min = res.msg.tmpAndHumSum.humMin;
          }
          this.displayEchart5(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts5() {
      this.displayEchart5();
    },
    // 第6个echarts图
    displayEchart6(data) {
      this.myChart6 = echarts.init(document.getElementById("chart6"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        // 湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp6max = tmp0max;
      //   this.tmp6min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp6max = maxs;
      //   this.tmp6min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option6 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp6min,
            max: this.tmp6max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      this.myChart6.setOption(option6);
      // console.log(this.allnodedd)
    },
    drawChart6() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[5].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp6max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp6max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp6min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp6min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart6(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts6() {
      this.displayEchart6();
    },
    // 第7个echarts图
    displayEchart7(data) {
      this.myChart7 = echarts.init(document.getElementById("chart7"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp7max = tmp0max;
      //   this.tmp7min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp7max = maxs;
      //   this.tmp7min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option7 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp7min,
            max: this.tmp7max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart7.setOption(option7);
      // console.log(this.allnodedd)
    },
    drawChart7() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: 1,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[6].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp7max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp7max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp7min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp7min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart7(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts7() {
      this.displayEchart7();
    },
    // 第8个echarts图
    displayEchart8(data) {
      this.myChart8 = echarts.init(document.getElementById("chart8"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp8max = tmp0max;
      //   this.tmp8min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp8max = maxs;
      //   this.tmp8min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option8 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp8min,
            max: this.tmp8max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart8.setOption(option8);
      // console.log(this.allnodedd)
    },
    drawChart8() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[7].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp8max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp8max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp8min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp8min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart8(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts8() {
      this.displayEchart8();
    },
    // 第9个echarts图
    displayEchart9(data) {
      this.myChart9 = echarts.init(document.getElementById("chart9"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp9max = tmp0max;
      //   this.tmp9min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp9max = maxs;
      //   this.tmp9min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option9 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp9min,
            max: this.tmp9max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart9.setOption(option9);
      // console.log(this.allnodedd)
    },
    drawChart9() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[8].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp9max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp9max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp9min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp9min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart9(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts9() {
      this.displayEchart9();
    },
    // 第10个echarts图
    displayEchart10(data) {
      this.myChart10 = echarts.init(document.getElementById("chart10"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp10max = tmp0max;
      //   this.tmp10min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp10max = maxs;
      //   this.tmp10min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option10 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp10min,
            max: this.tmp10max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart10.setOption(option10);
      // console.log(this.allnodedd)
    },
    drawChart10() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[9].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp10max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp10max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp10min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp10min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart10(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts10() {
      this.displayEchart10();
    },
    // 第11个echarts图
    displayEchart11(data) {
      this.myChart11 = echarts.init(document.getElementById("chart11"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp11max = tmp0max;
      //   this.tmp11min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp11max = maxs;
      //   this.tmp11min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option11 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp11min,
            max: this.tmp11max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart11.setOption(option11);
      // console.log(this.allnodedd)
    },
    drawChart11() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }
      let para = {
        size: 999,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[10].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp11max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp11max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp11min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp11min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart11(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts11() {
      this.displayEchart11();
    },
    // 第12个echarts图
    displayEchart12(data) {
      this.myChart12 = echarts.init(document.getElementById("chart12"));
      var tmp1Array = [];
      var timeArray = [];
      var hum1Array = [];
      var flag = true;
      for (var i = 0; i < data.length; i++) {
        if (data[i].temperature1) {
          tmp1Array[i] = data[i].temperature1;
        } else {
          tmp1Array[i] = "";
        }
        //湿度1
        if (data[i].hum) {
          hum1Array[i] = data[i].hum;
        } else {
          hum1Array[i] = "";
        }
        timeArray[i] = data[i].gpsTime;
      }
      var tmp0max = tmp1Array[1];
      var tmp0min = tmp1Array[1];
      var hum0max = hum1Array[1];
      var hum0min = hum1Array[1];
      // for (var i = 0; i < data.length; i++) {
      //   // 最大温度
      //   if (tmp0max > tmp1Array[i]) {
      //     tmp0max = tmp0max;
      //   } else {
      //     tmp0max = tmp1Array[i];
      //   }
      //   // 最小温度
      //   if (tmp0min < tmp1Array[i]) {
      //     tmp0min = tmp0min;
      //   } else {
      //     tmp0min = tmp1Array[i];
      //   }
      //   // 最大湿度
      //   if (hum0max > hum1Array[i]) {
      //     hum0max = hum0max;
      //   } else {
      //     hum0max = hum1Array[i];
      //   }
      //   // 最小湿度
      //   if (hum0min < hum1Array[i]) {
      //     hum0min = hum0min;
      //   } else {
      //     hum0min = hum1Array[i];
      //   }
      // }
      // if (hum0max == "") {
      //   hum0max = 0;
      //   hum0min = 0;
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }
      //   this.tmp12max = tmp0max;
      //   this.tmp12min = tmp0min;
      // } else {
      //   if (tmp0max == "") {
      //     tmp0max = 0;
      //   }

      //   var maxs = hum0max;
      //   var mins = hum0min;
      //   if (tmp0max > hum0max) {
      //     maxs = tmp0max;
      //   }
      //   if (tmp0min < hum0min) {
      //     mins = tmp0min;
      //   }
      //   this.tmp12max = maxs;
      //   this.tmp12min = mins;
      // }
      var hum1 = {
        name: "湿度一",
        type: "line",
        data: hum1Array,
        itemStyle: {
          normal: {
            color: "#F9BF66",
            lineStyle: {
              color: "#F9BF66"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
        // ,
        // markLine: {
        //   data: [{ type: "average", name: "平均值" }]
        // }
      };
      var tmp1 = {
        name: "温度一",
        type: "line",
        data: tmp1Array,
        itemStyle: {
          normal: {
            opacity: 0,
            color: "#60A0E6",
            lineStyle: {
              color: "#60A0E6"
            }
          }
        },
        markPoint: {
          symbolSize: 40,
          data: [
            {
              type: "max",
              name: "最大值"
            },
            {
              type: "min",
              name: "最小值"
            }
          ]
        }
      };
      const option12 = {
        grid: {
          x: 60,
          y: 60,
          x2: 35,
          y2: 30,
          borderWidth: 1
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["温度一", "湿度一"]
        },
        toolbox: {
          show: true,
          feature: {
            // saveAsImage: {}
          }
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            axisLabel: {
              fontSize: "9"
            },
            data: (function() {
              var list = [];
              for (var i = 0; i < data.length; i++) {
                list.push(data[i].gpsTime);
              }
              return list;
            })()
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "（°C）",
            min: this.tmp12min,
            max: this.tmp12max,
            axisLabel: {
              formatter: "{value} "
            }
          },
          {
            type: "value",
            name: "（%）",
            min: 0,
            max: 100,
            axisLabel: {
              formatter: "{value} "
            }
          }
        ],

        series: [tmp1, hum1]
      };
      // console.log(allnodedd);
      //  console.log(option)
      this.myChart12.setOption(option12);
      // console.log(this.allnodedd)
    },
    drawChart12() {
      var that = this;
      if (this.value3 == "") {
        this.value3 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);

        this.value4 = new Date(new Date().getTime());
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");
      }

      let para = {
        size: 999,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[11].id
      };
      //查询的结果
      this.loading = true;
      history(para).then(res => {
        this.loading = false;
        var data = res.msg.data;
        if (res.code == 1) {
          if (
            res.msg.tmpAndHumSum.humMax > res.msg.tmpAndHumSum.temperatureMax
          ) {
            this.tmp12max = res.msg.tmpAndHumSum.humMax;
          } else {
            this.tmp12max = res.msg.tmpAndHumSum.temperatureMax;
          }
          if (
            res.msg.tmpAndHumSum.humMin > res.msg.tmpAndHumSum.temperatureMin
          ) {
            this.tmp12min = res.msg.tmpAndHumSum.temperatureMin;
          } else {
            this.tmp12min = res.msg.tmpAndHumSum.humMin;
          }
          this.total = res.msg.total;
          this.displayEchart12(data);
        } else {
          this.open1();
        }
      });
    },
    drawCharts12() {
      this.displayEchart12();
    },
    // 第13个echarts图
    // 画图
    getUsers() {
      this.xianshi = true;
      this.drawChart1();
      this.drawChart2();
      this.drawChart3();
      this.drawChart4();
      this.drawChart5();
      this.drawChart6();
      this.drawChart7();
      this.drawChart8();
      this.drawChart9();
      this.drawChart10();
      this.drawChart11();
      this.drawChart12();
    },
    open8() {
      this.$message({
        showClose: true,
        message: "开始时间要小于结束时间",
        type: "warning"
      });
    },
    getUserst() {
      var that = this;
      if (this.value1 > this.value2) {
        this.open8();
        return;
      }
      that.value1 =
        !that.value1 || that.value1 == ""
          ? ""
          : util.formatDate.format(new Date(that.value1), "yyyy-MM-dd hh:mm");
      that.value2 =
        !that.value2 || that.value2 == ""
          ? ""
          : util.formatDate.format(new Date(that.value2), "yyyy-MM-dd hh:mm");

      this.value3 = this.value1;
      this.value4 = this.value2;

      var that = this;
      let para = {
        page: 1,
        size: 99,
        unitIds: this.filters.name,
        vehicleIds:this.vehicleIds
        // nodename: that.filters.name
      };
      this.allnode = [];

      //查询的结果
      nodeinfo(para).then(res => {
        console.log(res)
        this.allnode = res.msg.rows;
        this.allnums = res.msg.rows;
        this.getUsers();
      });

      // this.drawChart1();
      // this.drawChart2();
      // this.drawChart3();
      // this.drawChart4();
      // this.drawChart5();
      // this.drawChart6();
      // this.drawChart7();
      // this.drawChart8();
      // this.drawChart9();
      // this.drawChart10();
      // this.drawChart11();
      // this.drawChart12();
    },

    jump_info(index) {
      // alert(this.page)
      this.newadds = true;
      var that = this;
      this.num = index;
      let para = {
        size: that.size,
        page: this.page,
        startTime: this.value3,
        endTime: this.value4,
        vehicleId: this.allnode[index - 1].id,
        interval: this.interval
      };
      history(para).then(res => {
        console.log(res);
        var data = res.msg.data;
        if (res.code == 1) {
          this.total = res.msg.total;
          this.all_node = res.msg.data;
        } else {
          this.open1();
        }
        this.page = 1;
        this.size = 15;
      });
    },
    delet() {
      this.newadds = false;
    }
  }
};
</script>
<style>
#shebeis .el-input__inner {
  border: 1px solid #fff;
}
#shebeis .el-input {
  width: 250px;
}
#shebeis .el-select__tags {
  left: -2px;
  margin-top: -3px;
  margin-right: 6px;
}
#shebeis .el-select .el-tag {
  margin: 3px 4px 3px 6px;
}
#shebeis .el-select__tags span {
  border: 1px solid #fff;
  color: black;
  background: #fff;
  /* opacity:1; */
}
#chart1 > canvas {
  height: 230px;
  top: 40px;
}
#interval_time .el-input__inner {
  width: 45px;
  margin-right: 25px;
}
.toolbar .el-select {
  width: 150px;
}
</style>

<style scoped>
.footer-fenye {
  position: absolute;
  border-top: solid 1px #e4e4e4;
  padding: 10px 1% 10px 1%;
  bottom: 0;
  left: 0;
  width: 98%;
  background: #fff;
  z-index: 100;
}

.chart-container {
  width: 100%;
}
.chart-container .el-col {
  margin-bottom: 20px;
  float: left;
}

.chart1-container {
  /* height:560px; */
  overflow-y: scroll;
  overflow-x: hidden;
}

.el-col {
  background: #fff;
}

.toolbar {
  box-shadow: 0 0 6px 0 #dcdfe6;
}

.newadd {
  position: absolute;
  left: 0px;
  top: 0px;
}

.content {
  position: absolute;
  top: 0px;
  right: 0px;
  z-index: 999;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.568);
}

.contenter {
  overflow: hidden;
  position: relative;
  width: 85%;
  height: 600px;
  margin: 40px auto;
}

.delet {
  width: 50px;
  height: 50px;
  text-align: right;
  line-height: 50px;
  float: right;
  font-size: 16px;
  font-weight: normal;
  color: #fff;
  cursor: pointer;
}

.jump_info {
  width: 20px;
  height: 20px;
  position: absolute;
  right: 35px;
  top: 6px;
  z-index: 99;
}
.titleNname {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width: 100px;
  height: 20px;
  position: absolute;
  left: 16px;
  top: 4px;
  z-index: 99;
  font-size: 13px;
  font-weight: normal;
  color: #60a0e6;
}
.toolbar-bot .el-pagination {
  float: right;
}
</style>