<template>
    <div style="padding:0 10px;margin-top:10px;">
        <el-button @click="open1" v-show="false">消息</el-button>
        <el-button @click="open2" v-show="false">消息</el-button>
        <el-button @click="open3" v-show="false">消息</el-button>
        <el-button @click="open4" v-show="false">消息</el-button>
        <el-button @click="open5" v-show="false">消息</el-button>
        <el-button @click="open6" v-show="false">消息</el-button>
        <el-button @click="open7" v-show="false">消息</el-button>
        <el-button @click="open8" v-show="false">消息</el-button>
        <el-button @click="open9" v-show="false">消息</el-button>
        <el-button @click="open10" v-show="false">消息</el-button>
        <el-button @click="open11" v-show="false">消息</el-button>
        <el-button @click="open12" v-show="false">消息</el-button>
        <el-button @click="open13" v-show="false">消息</el-button>
        <el-button @click="open20" v-show="false">消息</el-button>
        <el-button @click="open21" v-show="false">消息</el-button>
        <section>
            <!--头部功能栏-->
            <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
                <el-form :inline="true" :model="filters">
                    <el-form-item label="冷库列表" style="width:250px;">
                        <el-select v-model="select" filterable @change="select_node" placeholder="请选择" style="width:150px;">
                            <el-option v-for="item in oprations" :key="item.index" :label="item.name" :value="item.id" ref="dataInfo">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="设备名称" id="shebeis" style="margin-left:-1%">
                        <div style="width: 149px;height: 30px;border:1px solid #BFCBD9;border-radius: 5px;overflow:hidden;">
              <el-select v-model="value11" @change="selectAll" multiple collapse-tags placeholder="请选择" style="width: 200px;margin-bottom:-100px;">
                <el-option v-for="item in allnums" :key="item.id" :label="item.nodename" :value="item.id" style="width: 200px">
                </el-option>
              </el-select>

            </div>
                    </el-form-item>
                    <el-form-item label="时间区间">
                        <div class="block">
                            <el-date-picker v-model="value1" type="datetime" value-format="yyyy-MM-dd" placeholder="选择开始日期时间">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <el-form-item label="-">
                        <div class="block">
                            <el-date-picker v-model="value2" type="datetime" value-format="yyyy-MM-dd" placeholder="选择结束日期时间">
                            </el-date-picker>
                        </div>
                    </el-form-item>
                    <!-- <el-form-item label="设备名称">
            <el-input v-model="filters.name" placeholder="请输入设备名称" style="width:200px;" @keyup.enter.native="getUsers"></el-input>
          </el-form-item> -->
                    <el-form-item>
                        <el-button type="primary" v-on:click="getUsers">查询</el-button>
                    </el-form-item>
                    <!-- <el-form-item>
            <el-button type="primary" @click="handleAdd">报警设置</el-button>
          </el-form-item> -->
                    <el-form-item style="float:right;cursor: pointer;padding-left:10px;">
                        <i>
                            <img src="../../assets/icon/excel.png" @click="Pdf()">
                        </i>
                        <a style="color:#328fea;text-decoration:none;" @click="Pdf()">Pdf</a>
                    </el-form-item>
                    <el-form-item style="float:right;cursor: pointer;">
                        <i>
                            <img src="../../assets/icon/excel.png" @click="exportTable()">
                        </i>
                        <a style="color:#328fea;text-decoration:none;" @click="exportTable()">Excel</a>
                    </el-form-item>

                </el-form>
            </el-col>
            <!--表格列表-->
            <el-table :data="allnum" highlight-current-row :height="windowHeigh" @click="toggleSelection" v-loading="loading" style="border-right:solid 1px #dfe6ec"
                @selection-change="handleSelectionChange">
                <!-- <el-table-column type="selection" width="55" label="全选/取消" :selectable='checkboxInit'>
        </el-table-column> -->
                <el-table-column prop="sendTime" label="报警时间" width="170">
                </el-table-column>
                <el-table-column prop="nodeName" label="名称" width="130" :show-overflow-tooltip="true">
                </el-table-column>
                <!-- <el-table-column prop="alarmType" label="类型" min-width="40" :show-overflow-tooltip="true">
                </el-table-column> -->
                <!-- <el-table-column prop="sendType" label="发送类型(c)" min-width="70" :show-overflow-tooltip="true">
                </el-table-column> -->
                <el-table-column label="发送类型" width="90">
                    <template slot-scope="scope">
                        <span v-if="scope.row.sendType == 'email'">邮箱</span>
                        <span v-if="scope.row.sendType == 'weixin'">微信</span>
                        <span v-if="scope.row.sendType == 'sms'">短信</span>
                    </template>
                </el-table-column>
                <el-table-column prop="sendNo" label="发送地址" min-width="90" :show-overflow-tooltip="true">
                </el-table-column>
                <el-table-column prop="sendContent" label="报警信息" min-width="240" :show-overflow-tooltip="true">
                </el-table-column>
                <!-- <el-table-column prop="sendResult" label="报警结果" min-width="180" :show-overflow-tooltip="true">
                </el-table-column> -->
                <el-table-column label="报警结果" width="180">
                    <template slot-scope="scope">
                        <span class="blue" v-if="scope.row.sendResult == '发送成功'">{{scope.row.sendResult}}</span>
                        <span class="red" v-else-if="scope.row.sendResult == '发送失败'">{{scope.row.sendResult}}</span>
                        <span class="black" v-else>{{scope.row.sendResult}}</span>
                    </template>
                </el-table-column>
            </el-table>

        </section>
        <el-footer class="footer-bottom">
            <!--工具条-->
            <el-col :span="24" class="toolbar-bot">
                <span class="demonstration" style="float: left; margin-top: 10px;">共:{{total}}条</span>
                <el-pagination style="cursor:pointer" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage1"
                    :page-size="size" layout="prev, pager, next, jumper" :total="total">
                </el-pagination>
            </el-col>
        </el-footer>
    </div>
</template>
<script>
// 获取浏览器可视窗口高度
var liuHeight = document.documentElement.clientHeight - 220;
import htmlToPdf from "../../components/htmlToPdf/htmlToPdf";
// 格式化时间
import util from "../../common/js/util";
import {
  getUserListPage,
  removeUser,
  batchRemoveUser,
  editUser,
  addUser,
  unitTree,
  equipment,
  Alarmrecord,
  saveWarnBatch,
  getWarnData
} from "../../api/api";
export default {
  inject: ["reload"],
  data() {
    var Tmp1max = "";
    var Tmp1min = "";
    var checkTmp1min = (rule, value, callback) => {
      Tmp1max = value;
      if (value === "") {
        return callback(new Error("温度不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          if (Tmp1min === "") {
            callback();
          } else {
            if (value > Tmp1min) {
              callback(new Error("要小于最大值"));
            } else {
              callback();
            }
          }
        }
      }, 1000);
    };
    var checkTmp1max = (rule, value, callback) => {
      Tmp1min = value;
      // console.log(Tmp1max);
      if (value === "") {
        return callback(new Error("温度不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          if (Tmp1max === "") {
            callback();
          } else {
            if (value < Tmp1max) {
              callback(new Error("要大于最小值"));
            } else {
              callback();
            }
          }
        }
      }, 1000);
    };
    var Hum1min = "";
    var Hum1max = "";
    var checkHum1min = (rule, value, callback) => {
      Hum1min = value;
      if (value === "") {
        return callback(new Error("湿度不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          if (value < 0) {
            callback(new Error("必须大于0"));
          } else {
            if (Hum1max === "") {
              callback();
            } else {
              if (value > Hum1max) {
                callback(new Error("要小于最大值"));
              } else {
                callback();
              }
            }
          }
        }
      }, 1000);
    };
    var checkTHum1max = (rule, value, callback) => {
      Hum1max = value;
      if (value === "") {
        return callback(new Error("湿度不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          if (value < Hum1min) {
            callback(new Error("要大于最小值"));
          } else {
            callback();
          }
        }
      }, 1000);
    };
    var checkLevel2NextTime = (rule, value, callback) => {
      if (value === "") {
        return callback(new Error("不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          callback();
        }
      }, 1000);
    };
    var checkLevel3NextTime = (rule, value, callback) => {
      if (value === "") {
        return callback(new Error("不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          callback();
        }
      }, 1000);
    };
    var checkLevel4NextTime = (rule, value, callback) => {
      if (value === "") {
        return callback(new Error("不能为空"));
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error("请输入数字值"));
        } else {
          callback();
        }
      }, 1000);
    };
    return {
      // checkboxInit:true,
      toggletion: "",
      toggletions: [],
      selednum: 0,
      seled: false,
      Dropdownboxnum: 0,
      seletnum: 0,
      getnum: 0,
      inputValue: "",
      oldOptions: [],
      allnumsId: [],
      value11: "",
      value12: "",
      value4: "",
      value3: "",
      value2: "",
      value1: "",
      spanShow: false,
      // 正则
      addForm: {
        tmp1max: "",
        tmp1min: "",
        hum1max: "",
        hum1min: "",
        level1Emails: "",
        level1Emai2s: "",
        level1Emai3s: "",
        level1Emai4s: "",
        level1Mobiles: "",
        level1Mobi2es: "",
        level1Mobi3es: "",
        level1Mobi4es: "",
        level1NextTime: "",
        level2NextTime: "",
        level3NextTime: "",
        level4NextTime: "",
        level1WeiXin: "",
        level2WeiXin: "",
        level3WeiXin: "",
        level4WeiXin: ""
      },
      rules2: {
        tmp1max: [
          {
            validator: checkTmp1max,
            trigger: "blur"
          }
        ],
        level2NextTime: [
          {
            validator: checkLevel2NextTime,
            trigger: "blur"
          }
        ],
        level3NextTime: [
          {
            validator: checkLevel3NextTime,
            trigger: "blur"
          }
        ],
        level4NextTime: [
          {
            validator: checkLevel4NextTime,
            trigger: "blur"
          }
        ],
        tmp1min: [
          {
            validator: checkTmp1min,
            trigger: "blur"
          }
        ],
        hum1max: [
          {
            validator: checkTHum1max,
            trigger: "blur"
          }
        ],
        hum1min: [
          {
            validator: checkHum1min,
            trigger: "blur"
          }
        ]
      },
      // 报警设置
      num: "",
      currentPage1: 1,
      total: 0,
      page: 1,
      size: 20,
      nodeIds: [],
      windowHeigh: "",
      // 报警设置结束
      checkboxInit: "",
      multipleSelection: [],
      title: "报警设置",
      filters: {
        plate: "",
        name: ""
      },
      select: "",
      oprations: [],
      allnum: [],
      allnums: [],
      options: [],
      users: [],
      loading: false,
      listLoading: true,
      sels: [], //列表选中列
      editFormVisible: false, //编辑界面是否显示
      editLoading: false,
      editFormRules: {
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        plate: [
          {
            required: true,
            message: "请输入车牌号",
            trigger: "blur"
          }
        ]
      },
      //编辑界面数据
      editForm: {
        id: 0,
        name: "",
        plate: "",
        sex: -1,
        age: 0,
        birth: "",
        addr: ""
      },
      addFormVisible: false, //新增界面是否显示
      addLoading: false,
      WeiXintest: 1,
      Emailtest: 1,
      Mobiletest: 1,
      addFormRules: {
        name: [
          {
            required: true,
            message: "请输入姓名",
            trigger: "blur"
          }
        ],
        plate: [
          {
            required: true,
            message: "请输入车牌号",
            trigger: "blur"
          }
        ]
      }
    };
  },
  created: function() {
    this.windowHeigh = liuHeight;
    unitTree().then(data => {
      if (data.data.code == -1) {
        this.$message({
          message: msg,
          type: "error"
        });
      } else {
        this.oprations = data.data.msg;
        this.select = data.data.msg[0].id;
      }
    });
  },
  methods: {
    allnumId() {
      var allnumIds = [];

      //  for(var i=0;i<this.allnums.length;i++){
      //              allnumIds.push(this.allnums[i].nodename)
      //      }
      //  alert(this.allnums)
      //  this.value11=allnumIds
      // this.value11.push('泗泾冷藏库0-5°')
      // if(this.value11.length==4){
      //     this.value11=null
      // }
      //  console.log(this.value11)
      // //  this.value11=[]

      //  console.log(allnumIds)
    },
    // 下拉列表
    selectAll(val) {
      if (this.Dropdownboxnum > 3) {
        console.log(val);
        if (val.includes(-1)) {
          this.value11.splice(val.indexOf(0), 1);
          this.value11 = [];
        }
        if (val.includes(0)) {
          this.value11 = this.value12;
        }
      } else {
        if (val.includes(-1)) {
          this.value11.splice(val.indexOf(-1), 1);
        }
      }
      this.Dropdownboxnum++;
    },
    toggletion(rows) {
      // if (rows) {
      //   rows.forEach(row => {
      //     this.$refs.multipleTable.toggleRowSelection(row);
      //   });
      // } else {
      //   this.$refs.multipleTable.clearSelection();
      // }
    },

    handleChange(val) {
      console.log(val);
      var toggletion = [];
      for (var i = 0; i < val.length; i++) {
        toggletion.push(val[i].id);
      }
      this.toggletion = toggletion.join();
      this.toggletions = toggletion;
      console.log(this.toggletion);
    },
    // 下拉列表
    select_node() {
      // alert(1)
      this.value11 = [];
      this.filters.name = "";
      this.getUserst();
    },
    open1() {
      this.$message({
        message: "请填写完整信息",
        type: "warning"
      });
    },
    open2() {
      this.$message({
        message: "提交成功",
        type: "success"
      });
    },
    open3() {
      this.$message({
        message: "请勾选设备",
        type: "warning"
      });
    },
    open4() {
      this.$message({
        message: "信息填写有误",
        type: "warning"
      });
    },
    open5() {
      this.$message({
        message: "温度最大值要大于最小值",
        type: "warning"
      });
    },
    open6() {
      this.$message({
        message: "湿度最大值要大于最小值",
        type: "warning"
      });
    },
    open7() {
      this.$message({
        message: "阀值设置没有填写完整或填写有误",
        type: "warning"
      });
    },
    open8() {
      this.$message({
        message: "升级报警设置没有填写完整或填写有误",
        type: "warning"
      });
    },
    open9() {
      this.$message({
        message: "邮箱格式填写有误",
        type: "warning"
      });
    },
    open10() {
      this.$message({
        message: "手机号没有填写完整或填写有误",
        type: "warning"
      });
    },
    open11() {
      this.$message({
        message: "微信号没有填写完整",
        type: "warning"
      });
    },
    open12() {
      this.$message({
        message: "阀值设置温度值不能相等",
        type: "warning"
      });
    },
    open13() {
      this.$message({
        message: "阀值设置湿度值不能相等",
        type: "warning"
      });
    },
    open20() {
      this.$message({
        message: "联系方式至少选填一个",
        type: "warning"
      });
    },
    open21() {
      this.$message({
        message: "暂无数据",
        type: "warning"
      });
    },
    open23() {
      this.$message({
        message: "请选择要查询的设备名称",
        type: "warning"
      });
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },

    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // excel导出
    exportTable() {
      // this.loading2=true;
      // setTimeout(()=>{
      //   // this.loading2=false
      // },3000)
      var that = this;
      that.size = 99999;
      that.start = 1;
      window.location.href =
        "http://114.55.138.209:8091/jygpsTmp/syswarningsendinfo/exportExcel?vehicleId=" +
        this.value11 +
        "&startTime=" +
        that.value3 +
        "&endTime=" +
        that.value4 +
        "&size=" +
        that.size +
        "&start=" +
        that.start;
      that.size = 15;
    },
    Pdf() {
      // this.loading2=true;
      // setTimeout(()=>{
      //   // this.loading2=false
      // },3000)
      var that = this;
      that.size = 99999;
      that.start = 1;
      window.location.href =
        "http://114.55.138.209:8091/jygpsTmp/syswarningsendinfo/exportPdf?vehicleId=" +
        this.value11 +
        "&startTime=" +
        that.value3 +
        "&endTime=" +
        that.value4 +
        "&size=" +
        that.size +
        "&start=" +
        that.start;
      that.size = 15;
    },
    // excel导出结束
    closeShow() {
      // this.getUsers();
      this.addFormVisible = false;
      // this.handleSelectionChange();
      this.getUsers();
      this.handleSelectionChange();
    },
    handleSelectionChange(row) {
      // console.log(row)
      this.nodeIds = [];
      for (var i = 0; i < row.length; i++) {
        this.nodeIds[i] = row[i].id;
      }

      // console.log(row);
      // console.log(this.nodeIds);
    },
    //分页

    handleSizeChange(val) {
      // alert(`每页 ${val} 条`);
      this.size = val;
    },
    handleCurrentChange(val) {
      var inputVal = [];
      if (this.inputValue == "") {
        for (var i = 0; i < this.allnums.length; i++) {
          inputVal.push(this.allnums[i].id);
        }

        this.inputValue = inputVal.join();
      }
      this.page = val;
      this.getUsers();
    },
    // 获取id
    addId() {
      var that = this;
      let paras = {
        page: 1,
        size: 9999,
        unitIds: that.select
      };

      //查询的结果
      equipment(paras).then(res => {
        this.allnums = res.data.msg.rows;
        var abs = {
          nodename: "选择全部",
          id: 0
        };
        var abq = {
          nodename: "取消全部",
          id: -1
        };
        this.allnums.unshift(abs);
        this.allnums.unshift(abq);
        this.$nextTick(() => {
          for (var i = 0; i < this.allnums.length; i++) {
            this.allnumsId.push(res.data.msg.rows[i].id);
          }
        });
      });
    },
    //获取用户列表
    getUsers() {
      this.loading = true;
      var that = this;
      let paras = {
        page: 1,
        size: 9999,
        unitIds: that.select
      };
      // alert(that.select)
      // this.listLoading = true;
      //查询的结果
      equipment(paras).then(res => {
        this.allnums = res.data.msg.rows;
        var abs = {
          nodename: "选择全部",
          id: 0
        };
        var abq = {
          nodename: "取消全部",
          id: -1
        };
        this.allnums.unshift(abs);
        this.allnums.unshift(abq);
        console.log(this.allnums);
        this.listLoading = false;
        if (this.value1 == "") {
          this.value1 = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
          this.value2 = new Date(new Date().getTime());
          that.value1 =
            !that.value1 || that.value1 == ""
              ? ""
              : util.formatDate.format(
                  new Date(that.value1),
                  "yyyy-MM-dd hh:mm"
                );
          that.value2 =
            !that.value2 || that.value2 == ""
              ? ""
              : util.formatDate.format(
                  new Date(that.value2),
                  "yyyy-MM-dd hh:mm"
                );
        }

        this.value3 = this.value1;
        this.value4 = this.value2;
        that.value3 =
          !that.value3 || that.value3 == ""
            ? ""
            : util.formatDate.format(new Date(that.value3), "yyyy-MM-dd hh:mm");
        that.value4 =
          !that.value4 || that.value4 == ""
            ? ""
            : util.formatDate.format(new Date(that.value4), "yyyy-MM-dd hh:mm");

        if (this.getnum == 0) {
          var inputValue = "";
          inputValue = this.value11.join();
          var inputVal = [];
          if (inputValue == "") {
            for (var i = 0; i < this.allnums.length; i++) {
              inputVal.push(this.allnums[i].id);
            }

            inputValue = inputVal.join();
            this.value11 = inputVal;
            this.value12 = inputVal;
          }
        } else {
          var inputValue = "";
          inputValue = this.value11.join();
          var inputVal = [];
          if (inputValue == "") {
            this.open23();
            this.page = 1;
            this.total = 0;
            this.loading = false;
            this.allnum = [];
            return;
          }
        }
        this.getnum++;
        let para = {
          page: this.page,
          size: this.size,
          vehicleId: inputValue,
          inputValue: "",
          startTime: this.value3,
          endTime: this.value4
        };
        // this.listLoading = true;
        //查询的结果

        Alarmrecord(para).then(res => {
          this.allnum = res.msg.rows;
          this.total = res.msg.total;
          // console.log(JSON.parse((res.msg.rows[3].sendResult).slice(5)).success_count)
          if (this.total == 0) {
            this.open21();
          }
          // console.log(res);
          this.loading = false;
        });
      });
      this.toggletions.forEach(row => {
        this.$refs.multipleTable.toggleRowSelection(row);
      });
    },
    getUserst() {
      var that = this;
      let para = {
        page: 1,
        size: 9999,
        unitIds: that.select
      };

      console.log(para);
      this.listLoading = true;
      //查询的结果
      equipment(para).then(res => {
        this.allnums = res.data.msg.rows;
        var abs = {
          nodename: "选择全部",
          id: 0
        };
        var abq = {
          nodename: "取消全部",
          id: -1
        };
        this.allnums.unshift(abs);
        this.allnums.unshift(abq);
        var length = this.allnums.length;
        this.value12 = [];
        for (var i = 1; i < length; i++) {
          this.value12.push(this.allnums[i].id);
        }
        this.listLoading = false;
      });
    },

    //显示编辑界面
    spanShows() {
      this.spanShow = false;
    },
    //显示报警界面
    handleAdd: function() {
      this.title = "报警设置";
      if (this.nodeIds.length <= 0) {
        this.open3();
        return;
      }
      this.addFormVisible = true;
      var that = this;
      (that.addForm.tmp1max = ""),
        (that.addForm.tmp1min = ""),
        (that.addForm.hum1max = ""),
        (that.addForm.hum1min = ""),
        (that.addForm.level2NextTime = ""),
        (that.addForm.level3NextTime = ""),
        (that.addForm.level4NextTime = ""),
        (that.addForm.level1Emails = ""),
        (that.addForm.level2Emails = ""),
        (that.addForm.level3Emails = ""),
        (that.addForm.level4Emails = ""),
        (that.addForm.level1Mobiles = ""),
        (that.addForm.level2Mobiles = ""),
        (that.addForm.level3Mobiles = ""),
        (that.addForm.level4Mobiles = "");
      that.addForm.level1WeiXin = "";
      that.addForm.level2WeiXin = "";
      that.addForm.level3WeiXin = "";
      that.addForm.level4WeiXin = "";
    },
    handleEdit: function(index, row) {
      this.title = "编辑设置";
      this.addFormVisible = true;
      this.nodeIds = [];
      this.nodeIds.push(row.id);
      console.log(this.nodeIds);
      var that = this;
      let para = {
        id: that.nodeIds[0]
      };
      getWarnData(para).then(data => {
        console.log(data);
        (that.addForm.tmp1max = data.msg.tmp1max),
          (that.addForm.tmp1min = data.msg.tmp1min),
          (that.addForm.hum1max = data.msg.hum1max),
          (that.addForm.hum1min = data.msg.hum1min),
          (that.addForm.level2NextTime = data.msg.level2NextTime),
          (that.addForm.level3NextTime = data.msg.level3NextTime),
          (that.addForm.level4NextTime = data.msg.level4NextTime),
          (that.addForm.level1Emails = data.msg.level1Emails),
          (that.addForm.level2Emails = data.msg.level2Emails),
          (that.addForm.level3Emails = data.msg.level3Emails),
          (that.addForm.level4Emails = data.msg.level4Emails),
          (that.addForm.level1Mobiles = data.msg.level1Mobiles),
          (that.addForm.level2Mobiles = data.msg.level2Mobiles),
          (that.addForm.level3Mobiles = data.msg.level3Mobiles),
          (that.addForm.level4Mobiles = data.msg.level4Mobiles);
        that.addForm.level1WeiXin = data.msg.level1WeiXin;
        that.addForm.level2WeiXin = data.msg.level2WeiXin;
        that.addForm.level3WeiXin = data.msg.level3WeiXin;
        that.addForm.level4WeiXin = data.msg.level4WeiXin;
      });
    },
    clecl: function() {
      this.getUsers();
      this.handleSelectionChange();
    },
    //报警/编辑的提交
    addSubmit: function() {
      // this.addLoading=true
      if (this.addForm.tmp1max === "") {
        this.open7();
        return;
      } else {
        var reg = /^(-|\+)?\d+$/;
        if (!reg.test(this.addForm.tmp1max)) {
          // alert(this.addForm.tmp1max)
          this.open7();
          return;
        }
      }
      if (this.addForm.tmp1min === "") {
        this.open7();
        return;
      } else {
        var reg = /^(-|\+)?\d+$/;
        if (!reg.test(this.addForm.tmp1min)) {
          this.open7();
          return;
        }
      }
      if (this.addForm.tmp1max < this.addForm.tmp1min) {
        this.open5();
        return;
      }
      if (this.addForm.tmp1max == this.addForm.tmp1min) {
        this.open12();
        return;
      }
      if (this.addForm.level2NextTime === "") {
        this.open8();
        return;
      } else {
        var reg = /^[0-9]*$/;
        if (!reg.test(this.addForm.level2NextTime)) {
          this.open8();
          return;
        }
      }
      if (this.addForm.level3NextTime === "") {
        this.open8();
        return;
      } else {
        var reg = /^[0-9]*$/;
        if (!reg.test(this.addForm.level3NextTime)) {
          this.open8();
          return;
        }
      }
      if (this.addForm.level4NextTime === "") {
        this.open8();
        return;
      } else {
        var reg = /^[0-9]*$/;
        if (!reg.test(this.addForm.level4NextTime)) {
          this.open8();
          return;
        }
      }
      if (this.addForm.level1Emails !== "") {
        if (this.addForm.level1Emails.split("@").length < 2) {
          this.open9();
          return;
        }
        if (this.addForm.level1Emails.split("@").length === 2) {
          var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
          if (!reg.test(this.addForm.level1Emails)) {
            this.open9();
            return;
          }
        }
        if (this.addForm.level1Emails.split("@").length > 2) {
          if (this.addForm.level1Emails.split(",").length === 1) {
            this.open9();
            return;
          }
        }
      }
      if (this.addForm.level2Emails !== "") {
        if (this.addForm.level2Emails.split("@").length < 2) {
          this.open9();
          return;
        }
        if (this.addForm.level2Emails.split("@").length === 2) {
          var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
          if (!reg.test(this.addForm.level2Emails)) {
            this.open9();
            return;
          }
        }
        if (this.addForm.level2Emails.split("@").length > 2) {
          if (this.addForm.level2Emails.split(",").length === 1) {
            this.open9();
            return;
          }
        }
      }
      if (this.addForm.level3Emails !== "") {
        if (this.addForm.level3Emails.split("@").length < 2) {
          this.open9();
          return;
        }
        if (this.addForm.level3Emails.split("@").length === 2) {
          var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
          if (!reg.test(this.addForm.level3Emails)) {
            this.open9();
            return;
          }
        }
        if (this.addForm.level3Emails.split("@").length > 2) {
          if (this.addForm.level3Emails.split(",").length === 1) {
            this.open9();
            return;
          }
        }
      }
      if (this.addForm.level4Emails !== "") {
        if (this.addForm.level4Emails.split("@").length < 2) {
          this.open9();
          return;
        }
        if (this.addForm.level4Emails.split("@").length === 2) {
          var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
          if (!reg.test(this.addForm.level4Emails)) {
            this.open9();
            return;
          }
        }
        if (this.addForm.level4Emails.split("@").length > 2) {
          if (this.addForm.level4Emails.split(",").length === 1) {
            this.open9();
            return;
          }
        }
      }
      if (this.addForm.level1Mobiles !== "") {
        var reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regs = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regss = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (
          !reg.test(this.addForm.level1Mobiles) &&
          !regs.test(this.addForm.level1Mobiles) &&
          !regss.test(this.addForm.level1Mobiles)
        ) {
          this.open10();
          return;
        }
      }
      if (this.addForm.level2Mobiles !== "") {
        var reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regs = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regss = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (
          !reg.test(this.addForm.level2Mobiles) &&
          !regs.test(this.addForm.level2Mobiles) &&
          !regss.test(this.addForm.level2Mobiles)
        ) {
          this.open10();
          return;
        }
      }
      if (this.addForm.level3Mobiles !== "") {
        var reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regs = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regss = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (
          !reg.test(this.addForm.level3Mobiles) &&
          !regs.test(this.addForm.level3Mobiles) &&
          !regss.test(this.addForm.level3Mobiles)
        ) {
          this.open10();
          return;
        }
      }
      if (this.addForm.level4Mobiles !== "") {
        var reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regs = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        var regss = /^1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8},1[3|4|5|6|7|8|9][0-9]\d{8}$/;
        if (
          !reg.test(this.addForm.level4Mobiles) &&
          !regs.test(this.addForm.level4Mobiles) &&
          !regss.test(this.addForm.level4Mobiles)
        ) {
          this.open10();
          return;
        }
      }
      if (
        this.addForm.level1Mobiles === "" &&
        this.addForm.level2Mobiles === "" &&
        this.addForm.level3Mobiles === "" &&
        this.addForm.level4Mobiles === "" &&
        this.addForm.level1Emails === "" &&
        this.addForm.level2Emails === "" &&
        this.addForm.level3Emails === "" &&
        this.addForm.level4Emails === "" &&
        this.addForm.level1WeiXin === "" &&
        this.addForm.level2WeiXin === "" &&
        this.addForm.level3WeiXin === "" &&
        this.addForm.level4WeiXin === ""
      ) {
        this.open20();
        return;
      }
      this.num = "";
      for (var i = 0; i < this.nodeIds.length; i++) {
        var that = this;
        let para = {
          nodeIds: that.nodeIds[i],
          tmp1max: that.addForm.tmp1max,
          tmp1min: that.addForm.tmp1min,
          hum1max: that.addForm.hum1max,
          hum1min: that.addForm.hum1min,
          level2NextTime: that.addForm.level2NextTime,
          level3NextTime: that.addForm.level3NextTime,
          level4NextTime: that.addForm.level4NextTime,
          level1Emails: that.addForm.level1Emails,
          level2Emails: that.addForm.level2Emails,
          level3Emails: that.addForm.level3Emails,
          level4Emails: that.addForm.level4Emails,
          level1Mobiles: that.addForm.level1Mobiles,
          level2Mobiles: that.addForm.level2Mobiles,
          level3Mobiles: that.addForm.level3Mobiles,
          level4Mobiles: that.addForm.level4Mobiles,
          level1WeiXin: that.addForm.level1WeiXin,
          level2WeiXin: that.addForm.level2WeiXin,
          level3WeiXin: that.addForm.level3WeiXin,
          level4WeiXin: that.addForm.level4WeiXin
        };
        //查询的结果
        this.num = i;
        this.addLoading = false;
        saveWarnBatch(para).then(data => {
          var that = this;
          if (data.code == -1) {
            // if(i==this.nodeIds.length){
            this.open1();
            //  }
          } else {
            // alert(this.num+1==this.nodeIds.length)

            if (this.num + 1 == this.nodeIds.length) {
              this.num++;
              // this.open2(this.getUsers());
              this.open2();
              this.addFormVisible = false;
              this.handleSelectionChange();
              this.nodeIds = [];
              return;
            }
            (that.nodeIds = []),
              (that.addFormVisible = false),
              (that.tmp1max = ""),
              (that.tmp1min = ""),
              (that.hum1max = ""),
              (that.hum1min = ""),
              (that.level2NextTime = ""),
              (that.level3NextTime = ""),
              (that.level4NextTime = ""),
              (that.level1Emails = ""),
              (that.level2Emails = ""),
              (that.level3Emails = ""),
              (that.level4Emails = ""),
              (that.level1Mobiles = ""),
              (that.level2Mobiles = ""),
              (that.level3Mobiles = ""),
              (that.level4Mobiles = "");
            that.level1WeiXin = "";
            that.level2WeiXin = "";
            that.level3WeiXin = "";
            that.level4WeiXin = "";
          }
        });
      }
      this.getUsers();
      this.handleSelectionChange();
    }
  },

  // 表单验证
  // computed: {
  //   inpNum: {
  //     get: function () {
  //       return this.oldNum;
  //     },
  //     set: function (newValue) {
  //       this.oldNum = newValue.replace(/[^\d]/g, "");
  //     }
  //   }
  // },
  // beforeMount () {

  // },
  mounted() {
    this.getUsers();
  }
};
</script>
<style>
#tle {
  position: fixed;
  z-index: 999;
}
#tle .el-table th {
  background: #fff;
}
#tle .cell {
  background: #fff;
}

#tle .el-table td {
  height: 30px;
}
#tle .el-table__fixed {
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  box-shadow: none !important;
  -moz-box-shadow: none !important;
  -webkit-box-shadow: none !important;
  -moz-box-shadow: none !important;
  overflow-x: hidden !important;
}
#tle .el-table__body-wrapper {
  overflow-y: auto;
}
#tle .el-table__fixed-right {
  position: absolute !important;
  top: 0 !important;
  right: 0 !important;
  box-shadow: none !important;
  -moz-box-shadow: none !important;
  -webkit-box-shadow: none !important;
  -moz-box-shadow: none !important;
  overflow-x: hidden !important;
}
#shebeis .el-input__inner {
  border: 1px solid #fff;
}
#shebeis .el-input {
  width: 250px;
}
#shebeis .el-select__tags {
  left: -2px;
  margin-top: -3px;
  margin-right: 6px;
}
#shebeis .el-select .el-tag {
  margin: 3px 4px 3px 6px;
}
#shebeis .el-select__tags span {
  border: 1px solid #fff;
  color: black;
  background: #fff;
  /* opacity:1; */
}
.is-multiple {
  min-width: 100px !important;
}

.jian-ge .el-form-item__error {
  width: 200px;
}

.waring .el-dialog__body {
  border: 1px solid #bfcbd9;
}
.is-multiple {
  top: 107px !important;
}
</style>

<style scoped>
.black {
  color: black;
}
.el-form-item__error {
  width: 100px;
}

.el-col {
  background: #fff;
}

.toolbar-bot {
  text-align: right;
  margin-top: 10px;
}

.toolbar {
  box-shadow: 0 0 6px 0 #dcdfe6;
}

.el-form-item i img {
  width: 20px;
  height: 14px;
  display: inline-block;
  vertical-align: middle;
}

.el-form-item span {
  color: #328fea;
  line-height: 21px;
  margin-right: 10px;
}

.font-color {
  margin-right: 10px;
  color: #328fea;
}

.el-table {
  margin-bottom: 80px;
}

.footer-bottom {
  position: fixed;
  padding: 0 0 10px 0;
  bottom: 0;
  left: 224px;
  width: 81%;
  background: #fff;
  z-index: 100;
}

.el-dialog__header {
  background: darkgreen !important;
}

.title-color {
  width: 100px;
  text-align: center;
  float: left;
  line-height: 35px;
}

.title-span {
  width: 20px;
  text-align: center;
  float: left;
  line-height: 35px;
}

.title-fen {
  width: 40px;
  text-align: center;
  float: left;
  line-height: 35px;
}

.label {
  width: 100px;
  padding: 11px 0 11px 0 !important;
}

.jian-ge {
  padding: 6px 0;
}

.blue {
  color: #328fea;
}
.red {
  color: red;
}
.dialog-footer {
  text-align: center;
  margin: 40px 0 50px;
}

.baojing {
  width: 540px;
  background: #fff;
  border-radius: 3px;
  overflow: hidden;
  position: fixed;
  left: 50%;
  top: 15%;
  margin-left: -270px;
}

.radius-mg {
  float: right;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  overflow: hidden;
  color: #fff;
  text-align: center;
  background: #2e86df;
  margin: 2px 2px 0 0;
}
</style>